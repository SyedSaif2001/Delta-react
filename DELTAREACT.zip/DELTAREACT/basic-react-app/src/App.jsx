import Title from "./TTitle.jsx";
import Product from "./Product.jsx";
import ProductTab from "./ProductTab.jsx";
import "./App.css"




function App(){
  return(
   <ProductTab/>

  );
}
export default App


