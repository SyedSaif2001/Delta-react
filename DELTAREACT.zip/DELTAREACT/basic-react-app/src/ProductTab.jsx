import Product from "./Product.jsx";
function ProductTab(){
    return(
        <>
        <Product/>
        <Product/>
        <Product/>
       
        </>
    )
}
export default ProductTab;